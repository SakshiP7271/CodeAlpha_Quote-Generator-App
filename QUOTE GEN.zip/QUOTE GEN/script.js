const quotes = [
    "The greatest glory in living lies not in never falling, but in rising every time we fall. - Nelson Mandela",
    "The way to get started is to quit talking and begin doing. - Walt Disney",
    "Your time is limited, so don't waste it living someone else's life. - Steve Jobs",
    "If life were predictable it would cease to be life, and be without flavor. - Eleanor Roosevelt",
    "If you look at what you have in life, you'll always have more. If you look at what you don't have in life, you'll never have enough. - Oprah Winfrey"
];

const gradients = [
    "linear-gradient(to right, #ff7e5f, #feb47b)",
    "linear-gradient(to right, #43cea2, #185a9d)",
    "linear-gradient(to right, #ff6e7f, #bfe9ff)",
    "linear-gradient(to right, #00c6ff, #0072ff)",
    "linear-gradient(to right, #f7ff00, #db36a4)"
];

const quoteElement = document.getElementById('quote');
const newQuoteButton = document.getElementById('new-quote');
const shareQuoteButton = document.getElementById('share-quote');

newQuoteButton.addEventListener('click', () => {
    const randomQuoteIndex = Math.floor(Math.random() * quotes.length);
    quoteElement.textContent = quotes[randomQuoteIndex];
    
    const randomGradientIndex = Math.floor(Math.random() * gradients.length);
    document.body.style.background = gradients[randomGradientIndex];
});

shareQuoteButton.addEventListener('click', () => {
    const quoteText = quoteElement.textContent;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(quoteText)}`;
    window.open(twitterUrl, '_blank');
});
